//
// File: demo_controller_types.h
//
// Code generated for Simulink model 'demo_controller'.
//
// Model version                  : 1.33
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Sun Oct 22 21:32:45 2017
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_demo_controller_types_h_
#define RTW_HEADER_demo_controller_types_h_

// Forward declaration for rtModel
typedef struct tag_RTM_demo_controller_T RT_MODEL_demo_controller_T;

#endif                                 // RTW_HEADER_demo_controller_types_h_

//
// File trailer for generated code.
//
// [EOF]
//
