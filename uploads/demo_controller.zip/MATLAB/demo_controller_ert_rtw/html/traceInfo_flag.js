function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["demo_controller.cpp:125c47"]=1;
    this.traceFlag["demo_controller.cpp:132c46"]=1;
    this.traceFlag["demo_controller.cpp:132c70"]=1;
    this.traceFlag["demo_controller.cpp:133c38"]=1;
    this.traceFlag["demo_controller.cpp:138c52"]=1;
    this.traceFlag["demo_controller.cpp:139c42"]=1;
    this.traceFlag["demo_controller.cpp:173c31"]=1;
    this.traceFlag["demo_controller.cpp:173c34"]=1;
    this.traceFlag["demo_controller.cpp:174c31"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["demo_controller.cpp:119"]=1;
    this.lineTraceFlag["demo_controller.cpp:125"]=1;
    this.lineTraceFlag["demo_controller.cpp:132"]=1;
    this.lineTraceFlag["demo_controller.cpp:133"]=1;
    this.lineTraceFlag["demo_controller.cpp:138"]=1;
    this.lineTraceFlag["demo_controller.cpp:139"]=1;
    this.lineTraceFlag["demo_controller.cpp:172"]=1;
    this.lineTraceFlag["demo_controller.cpp:173"]=1;
    this.lineTraceFlag["demo_controller.cpp:174"]=1;
    this.lineTraceFlag["demo_controller.cpp:177"]=1;
    this.lineTraceFlag["demo_controller.cpp:180"]=1;
    this.lineTraceFlag["demo_controller.cpp:225"]=1;
    this.lineTraceFlag["demo_controller.cpp:228"]=1;
    this.lineTraceFlag["demo_controller.cpp:231"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
