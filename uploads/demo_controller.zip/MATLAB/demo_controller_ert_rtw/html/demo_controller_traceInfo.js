function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <Root>/w */
	this.urlHashMap["demo_controller:1"] = "demo_controller.cpp:122,253&demo_controller.h:93,176";
	/* <Root>/x */
	this.urlHashMap["demo_controller:2"] = "demo_controller.cpp:123,259&demo_controller.h:94,179";
	/* <Root>/PID Controller */
	this.urlHashMap["demo_controller:12"] = "demo_controller.h:234";
	/* <Root>/Sum */
	this.urlHashMap["demo_controller:3"] = "demo_controller.cpp:121&demo_controller.h:54";
	/* <Root>/Transfer Fcn */
	this.urlHashMap["demo_controller:13"] = "demo_controller.cpp:117,171,224&demo_controller.h:61,68,75";
	/* <Root>/y */
	this.urlHashMap["demo_controller:9"] = "demo_controller.cpp:116,267&demo_controller.h:99,182";
	/* <S1>/Derivative Gain */
	this.urlHashMap["demo_controller:12:1666"] = "demo_controller.cpp:128";
	/* <S1>/Filter */
	this.urlHashMap["demo_controller:12:1668"] = "demo_controller.cpp:129,176,227&demo_controller.h:62,69,76";
	/* <S1>/Filter Coefficient */
	this.urlHashMap["demo_controller:12:1669"] = "demo_controller.cpp:127&demo_controller.h:55";
	/* <S1>/Integral Gain */
	this.urlHashMap["demo_controller:12:1665"] = "demo_controller.h:215";
	/* <S1>/Integrator */
	this.urlHashMap["demo_controller:12:1667"] = "demo_controller.cpp:136,179,230&demo_controller.h:63,70,77";
	/* <S1>/Proportional Gain */
	this.urlHashMap["demo_controller:12:1664"] = "demo_controller.h:216";
	/* <S1>/Sum */
	this.urlHashMap["demo_controller:12:1663"] = "demo_controller.cpp:135&demo_controller.h:56";
	/* <S1>/SumD */
	this.urlHashMap["demo_controller:12:1670"] = "demo_controller.cpp:130";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "demo_controller"};
	this.sidHashMap["demo_controller"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>"] = {sid: "demo_controller:12"};
	this.sidHashMap["demo_controller:12"] = {rtwname: "<S1>"};
	this.rtwnameHashMap["<Root>/w"] = {sid: "demo_controller:1"};
	this.sidHashMap["demo_controller:1"] = {rtwname: "<Root>/w"};
	this.rtwnameHashMap["<Root>/x"] = {sid: "demo_controller:2"};
	this.sidHashMap["demo_controller:2"] = {rtwname: "<Root>/x"};
	this.rtwnameHashMap["<Root>/PID Controller"] = {sid: "demo_controller:12"};
	this.sidHashMap["demo_controller:12"] = {rtwname: "<Root>/PID Controller"};
	this.rtwnameHashMap["<Root>/Sum"] = {sid: "demo_controller:3"};
	this.sidHashMap["demo_controller:3"] = {rtwname: "<Root>/Sum"};
	this.rtwnameHashMap["<Root>/Transfer Fcn"] = {sid: "demo_controller:13"};
	this.sidHashMap["demo_controller:13"] = {rtwname: "<Root>/Transfer Fcn"};
	this.rtwnameHashMap["<Root>/y"] = {sid: "demo_controller:9"};
	this.sidHashMap["demo_controller:9"] = {rtwname: "<Root>/y"};
	this.rtwnameHashMap["<S1>/u"] = {sid: "demo_controller:12:1"};
	this.sidHashMap["demo_controller:12:1"] = {rtwname: "<S1>/u"};
	this.rtwnameHashMap["<S1>/Derivative Gain"] = {sid: "demo_controller:12:1666"};
	this.sidHashMap["demo_controller:12:1666"] = {rtwname: "<S1>/Derivative Gain"};
	this.rtwnameHashMap["<S1>/Filter"] = {sid: "demo_controller:12:1668"};
	this.sidHashMap["demo_controller:12:1668"] = {rtwname: "<S1>/Filter"};
	this.rtwnameHashMap["<S1>/Filter Coefficient"] = {sid: "demo_controller:12:1669"};
	this.sidHashMap["demo_controller:12:1669"] = {rtwname: "<S1>/Filter Coefficient"};
	this.rtwnameHashMap["<S1>/Integral Gain"] = {sid: "demo_controller:12:1665"};
	this.sidHashMap["demo_controller:12:1665"] = {rtwname: "<S1>/Integral Gain"};
	this.rtwnameHashMap["<S1>/Integrator"] = {sid: "demo_controller:12:1667"};
	this.sidHashMap["demo_controller:12:1667"] = {rtwname: "<S1>/Integrator"};
	this.rtwnameHashMap["<S1>/Proportional Gain"] = {sid: "demo_controller:12:1664"};
	this.sidHashMap["demo_controller:12:1664"] = {rtwname: "<S1>/Proportional Gain"};
	this.rtwnameHashMap["<S1>/Sum"] = {sid: "demo_controller:12:1663"};
	this.sidHashMap["demo_controller:12:1663"] = {rtwname: "<S1>/Sum"};
	this.rtwnameHashMap["<S1>/SumD"] = {sid: "demo_controller:12:1670"};
	this.sidHashMap["demo_controller:12:1670"] = {rtwname: "<S1>/SumD"};
	this.rtwnameHashMap["<S1>/y"] = {sid: "demo_controller:12:10"};
	this.sidHashMap["demo_controller:12:10"] = {rtwname: "<S1>/y"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
