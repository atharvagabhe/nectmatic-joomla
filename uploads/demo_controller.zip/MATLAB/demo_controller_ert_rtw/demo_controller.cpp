//
// File: demo_controller.cpp
//
// Code generated for Simulink model 'demo_controller'.
//
// Model version                  : 1.33
// Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
// C/C++ source code generated on : Sun Oct 22 21:32:45 2017
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "demo_controller.h"
#include "demo_controller_private.h"

//
// This function updates continuous states using the ODE3 fixed-step
// solver algorithm
//
void demo_controllerModelClass::rt_ertODEUpdateContinuousStates(RTWSolverInfo
  *si )
{
  // Solver Matrices
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 3;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  // Save the state values at time t in y, we'll use x as ynew.
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  // Assumes that rtsiSetT and ModelOutputs are up-to-date
  // f0 = f(t,y)
  rtsiSetdX(si, f0);
  demo_controller_derivatives();

  // f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*));
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  this->step();
  demo_controller_derivatives();

  // f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*));
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  this->step();
  demo_controller_derivatives();

  // tnew = t + hA(3);
  // ynew = y + f*hB(:,3);
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

// Model step function
void demo_controllerModelClass::step()
{
  if (rtmIsMajorTimeStep((&demo_controller_M))) {
    // set solver stop time
    rtsiSetSolverStopTime(&(&demo_controller_M)->solverInfo,
                          (((&demo_controller_M)->Timing.clockTick0+1)*
      (&demo_controller_M)->Timing.stepSize0));
  }                                    // end MajorTimeStep

  // Update absolute time of base rate at minor time step
  if (rtmIsMinorTimeStep((&demo_controller_M))) {
    (&demo_controller_M)->Timing.t[0] = rtsiGetT(&(&demo_controller_M)
      ->solverInfo);
  }

  // Outport: '<Root>/y' incorporates:
  //   TransferFcn: '<Root>/Transfer Fcn'

  demo_controller_Y.y = demo_controller_X.TransferFcn_CSTATE;

  // Sum: '<Root>/Sum' incorporates:
  //   Inport: '<Root>/w'
  //   Inport: '<Root>/x'

  demo_controller_B.Sum = demo_controller_U.w - demo_controller_U.x;

  // Gain: '<S1>/Filter Coefficient' incorporates:
  //   Gain: '<S1>/Derivative Gain'
  //   Integrator: '<S1>/Filter'
  //   Sum: '<S1>/SumD'

  demo_controller_B.FilterCoefficient = (0.0 * demo_controller_B.Sum -
    demo_controller_X.Filter_CSTATE) * 100.0;

  // Sum: '<S1>/Sum' incorporates:
  //   Integrator: '<S1>/Integrator'

  demo_controller_B.Sum_b = (demo_controller_B.Sum +
    demo_controller_X.Integrator_CSTATE) + demo_controller_B.FilterCoefficient;
  if (rtmIsMajorTimeStep((&demo_controller_M))) {
    rt_ertODEUpdateContinuousStates(&(&demo_controller_M)->solverInfo);

    // Update absolute time for base rate
    // The "clockTick0" counts the number of times the code of this task has
    //  been executed. The absolute time is the multiplication of "clockTick0"
    //  and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
    //  overflow during the application lifespan selected.

    ++(&demo_controller_M)->Timing.clockTick0;
    (&demo_controller_M)->Timing.t[0] = rtsiGetSolverStopTime
      (&(&demo_controller_M)->solverInfo);

    {
      // Update absolute timer for sample time: [0.1s, 0.0s]
      // The "clockTick1" counts the number of times the code of this task has
      //  been executed. The resolution of this integer timer is 0.1, which is the step size
      //  of the task. Size of "clockTick1" ensures timer will not overflow during the
      //  application lifespan selected.

      (&demo_controller_M)->Timing.clockTick1++;
    }
  }                                    // end MajorTimeStep
}

// Derivatives for root system: '<Root>'
void demo_controllerModelClass::demo_controller_derivatives()
{
  XDot_demo_controller_T *_rtXdot;
  _rtXdot = ((XDot_demo_controller_T *) (&demo_controller_M)->derivs);

  // Derivatives for TransferFcn: '<Root>/Transfer Fcn'
  _rtXdot->TransferFcn_CSTATE = 0.0;
  _rtXdot->TransferFcn_CSTATE += -demo_controller_X.TransferFcn_CSTATE;
  _rtXdot->TransferFcn_CSTATE += demo_controller_B.Sum_b;

  // Derivatives for Integrator: '<S1>/Filter'
  _rtXdot->Filter_CSTATE = demo_controller_B.FilterCoefficient;

  // Derivatives for Integrator: '<S1>/Integrator'
  _rtXdot->Integrator_CSTATE = demo_controller_B.Sum;
}

// Model initialize function
void demo_controllerModelClass::initialize()
{
  // Registration code
  {
    // Setup solver object
    rtsiSetSimTimeStepPtr(&(&demo_controller_M)->solverInfo,
                          &(&demo_controller_M)->Timing.simTimeStep);
    rtsiSetTPtr(&(&demo_controller_M)->solverInfo, &rtmGetTPtr
                ((&demo_controller_M)));
    rtsiSetStepSizePtr(&(&demo_controller_M)->solverInfo, &(&demo_controller_M
                       )->Timing.stepSize0);
    rtsiSetdXPtr(&(&demo_controller_M)->solverInfo, &(&demo_controller_M)
                 ->derivs);
    rtsiSetContStatesPtr(&(&demo_controller_M)->solverInfo, (real_T **)
                         &(&demo_controller_M)->contStates);
    rtsiSetNumContStatesPtr(&(&demo_controller_M)->solverInfo,
      &(&demo_controller_M)->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&(&demo_controller_M)->solverInfo,
      &(&demo_controller_M)->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&(&demo_controller_M)->solverInfo,
      &(&demo_controller_M)->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&(&demo_controller_M)->solverInfo,
      &(&demo_controller_M)->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&(&demo_controller_M)->solverInfo, (&rtmGetErrorStatus
      ((&demo_controller_M))));
    rtsiSetRTModelPtr(&(&demo_controller_M)->solverInfo, (&demo_controller_M));
  }

  rtsiSetSimTimeStep(&(&demo_controller_M)->solverInfo, MAJOR_TIME_STEP);
  (&demo_controller_M)->intgData.y = (&demo_controller_M)->odeY;
  (&demo_controller_M)->intgData.f[0] = (&demo_controller_M)->odeF[0];
  (&demo_controller_M)->intgData.f[1] = (&demo_controller_M)->odeF[1];
  (&demo_controller_M)->intgData.f[2] = (&demo_controller_M)->odeF[2];
  (&demo_controller_M)->contStates = ((X_demo_controller_T *) &demo_controller_X);
  rtsiSetSolverData(&(&demo_controller_M)->solverInfo, (void *)
                    &(&demo_controller_M)->intgData);
  rtsiSetSolverName(&(&demo_controller_M)->solverInfo,"ode3");
  rtmSetTPtr((&demo_controller_M), &(&demo_controller_M)->Timing.tArray[0]);
  (&demo_controller_M)->Timing.stepSize0 = 0.1;

  // InitializeConditions for TransferFcn: '<Root>/Transfer Fcn'
  demo_controller_X.TransferFcn_CSTATE = 0.0;

  // InitializeConditions for Integrator: '<S1>/Filter'
  demo_controller_X.Filter_CSTATE = 0.0;

  // InitializeConditions for Integrator: '<S1>/Integrator'
  demo_controller_X.Integrator_CSTATE = 0.0;
}

// Model terminate function
void demo_controllerModelClass::terminate()
{
  // (no terminate code required)
}

// Constructor
demo_controllerModelClass::demo_controllerModelClass()
{
}

// Destructor
demo_controllerModelClass::~demo_controllerModelClass()
{
  // Currently there is no destructor body generated.
}

// Root-level input access methods

// Root inport: '<Root>/w' set method
void demo_controllerModelClass::setw(real_T localArgInput)
{
  demo_controller_U.w = localArgInput;
}

// Root inport: '<Root>/x' set method
void demo_controllerModelClass::setx(real_T localArgInput)
{
  demo_controller_U.x = localArgInput;
}

// Root-level output access methods

// Root outport: '<Root>/y' get method
real_T demo_controllerModelClass::gety() const
{
  return demo_controller_Y.y;
}

// Real-Time Model get method
RT_MODEL_demo_controller_T * demo_controllerModelClass::getRTM()
{
  return (&demo_controller_M);
}

//
// File trailer for generated code.
//
// [EOF]
//
